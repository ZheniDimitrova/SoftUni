package com.dictionaryapp.model.entity.enums;

public enum LanguageEnum {
    GERMAN,
    SPANISH,
    FRENCH,
    ITALIAN;
}
