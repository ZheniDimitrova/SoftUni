package workingWithAbstractionsEx.p04_TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW
}
