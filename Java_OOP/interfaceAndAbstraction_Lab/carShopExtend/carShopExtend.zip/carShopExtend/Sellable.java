package carShopExtend;

public interface Sellable extends Car {

    double getPrice();
}
