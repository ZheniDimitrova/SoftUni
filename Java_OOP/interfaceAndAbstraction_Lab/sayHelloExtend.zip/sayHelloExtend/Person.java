package sayHelloExtend;

public interface Person {

    String getName();
    String sayHello();
}
