package workingWithAbstractionsEx.p01_CardSuit;

public enum CardSuit {

    CLUBS, DIAMONDS, HEARTS, SPADES;
}
