package birthdayCelebration;

public interface Identifiable {
    String getId();
}
