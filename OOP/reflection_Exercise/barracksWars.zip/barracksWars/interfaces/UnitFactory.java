package barracksWars.interfaces;

public interface UnitFactory {

    Unit createUnit(String unitType);
}